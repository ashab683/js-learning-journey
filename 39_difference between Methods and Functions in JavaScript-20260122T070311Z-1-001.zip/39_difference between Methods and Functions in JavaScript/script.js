const maths = {
  
E : 2.718281828459045,
add:function
 (a,b){
    return a+b
},

sub : function (a,b){
    return a-b

},
square : function(num){
    return num*num
},
cube : function(num){
return num*num*num
}
}
