function outer(){

function parent() {
    const a = 1;
    const b = 2;
    function add(){
console.log(a + b)
    } 
    return add;
}
 return parent()
}
const add1 = outer() 
 
 console.dir(add1)
