const h1 = document.querySelector('h1')
const container = document.querySelector(".container")
// const card = document.querySelector('.card')

// container.appendChild(h1)
// container.appendChild(h1.cloneNode(true))

// const firstImage = document.querySelector("img")

for (let i = 1; i <=100; i++) {
    const newImg = document.createElement('img')
    newImg.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${i}.png`

    container.append(newImg)
}


// const paragraph = document.createElement('p')
// const newImage = document.createElement('img')
// newImage.src = ' `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png`'

// paragraph.innerText='hello'
// paragraph.classList.add('my-para')

// paragraph.id = 

// container.append(paragraph)
